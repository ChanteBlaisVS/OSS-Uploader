﻿/*/#source 10 1 foo.js            
   this is the source directive */


  foo(bar);             

///#SoUrCe 5 42 fargo.htm       
  bar(foo)

