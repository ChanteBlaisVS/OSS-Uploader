﻿while{
    alert(;
}

/* unterminated comment