﻿for(ndx = 0)
{
    if (false {
    }
