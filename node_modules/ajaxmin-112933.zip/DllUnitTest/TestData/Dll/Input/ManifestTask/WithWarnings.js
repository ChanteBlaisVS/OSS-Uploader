﻿// unised parameters
function foo(a, b, c)
{
    // unused variable
    var d;

    // undefined variable reference
    return a + B;
}
