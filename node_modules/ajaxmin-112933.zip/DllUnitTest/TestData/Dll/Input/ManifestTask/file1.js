﻿(function(window, document, undefined)
{
    // start of our closure
    ///#IF DEBUG
    if (window.console)
    {
        console.log("entering closure");
    }
    ///#END
