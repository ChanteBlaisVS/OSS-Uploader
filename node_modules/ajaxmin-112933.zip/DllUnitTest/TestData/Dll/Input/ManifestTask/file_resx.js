﻿(function(window)
{
    window.alert(Lyrics.FirstLine + "\n" + Lyrics.SecondLine);
})(window);