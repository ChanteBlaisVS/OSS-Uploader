﻿    // end of our closure
})(window, document)
// a single-line comment that ends in the EOF