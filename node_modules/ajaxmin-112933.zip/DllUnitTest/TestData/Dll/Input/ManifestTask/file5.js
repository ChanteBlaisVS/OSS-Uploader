﻿(function($)
{
    // say hi when loaded
    $(function(){alert("hi!")})
})(jQuery)